﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.IO;
using System.Web.Script.Serialization;
using DotNetAssignment.Models;

namespace DotNetAssignment.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            List<DataModel> modelLst = GetPopularBikes();
            return View(modelLst);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public List<DataModel> GetPopularBikes()
        {
            WebRequest webRequest = HttpWebRequest.Create(new Uri("http://trekhiringassignments.blob.core.windows.net/interview/bikes.json"));
            WebResponse data = webRequest.GetResponse();
            String result;
            using (var reader = new StreamReader(data.GetResponseStream()))
            {
                result = reader.ReadToEnd();
            }
            List<BikeData> output = new JavaScriptSerializer().Deserialize<List<BikeData>>(result.ToString()).ToList();
            var p2 = output.Select(b => String.Join(",",b.bikes.OrderBy(p => p))).GroupBy(x=>x).Select(n => new {  Text= n.FirstOrDefault(),Value = n.Count() });
            List<DataModel> obj = new List<DataModel>();
           
            obj = p2.Select(x => new DataModel
            {
                BikesCombination = x.Text,
                Count = x.Value,
            }).ToList();

            return obj.OrderByDescending(x=>x.Count).Take(20).ToList();
        }

    }
}