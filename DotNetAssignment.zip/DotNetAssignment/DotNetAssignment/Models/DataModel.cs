﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DotNetAssignment.Models
{
    public class DataModel
    {
        public List<string> Key { get; set; }
        public Int32 Count { get; set; }
        public String BikesCombination { get;set; }
    }
        public class BikeData
        {
            public List<string> bikes { get; set; }
        }
}